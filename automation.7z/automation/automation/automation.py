import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Quaternion, PointStamped
from sensor_msgs.msg import JointState
from tf2_ros import TransformBroadcaster
import tf_transformations as tf_trans
from geometry_msgs.msg import TransformStamped
import numpy as np
import math



class RobotMotion(Node):
    
    def __init__(self):
        super().__init__('telema_node')
        self.point_subscriber=self.create_subscription(PointStamped,'/clicked_point',self.point_callback,10)
        self.velocity_publisher = self.create_publisher(Twist, 'cmd_vel', 10)

        self.joint_state_publisher = self.create_publisher(JointState, 'joint_states', 10)
        
        self.odom_broadcaster = TransformBroadcaster(self)
        self.path_points =[]
        self.current_point_index = 0
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.left_wheel_joint_rotation = 0.0
        self.right_wheel_joint_rotation = 0.0
        timer_period=0.1
        self.timer= self.create_timer(timer_period, self.update_motion)
        self.active = False
        self.get_logger().info("Robot is running...")
    def point_callback(self, msg):
       
        self.path_points.append((msg.point.x, msg.point.y))
        
        
        self.active = True  
        self.get_logger().info(f"Point added to path: {msg.point.x}, {msg.point.y}")
        self.current_point_index = len(self.path_points) - 1

    def update_motion(self):

        if not self.path_points:
            return
        if not self.active or self.current_point_index >= len(self.path_points):
            return
        target_x, target_y = self.path_points[self.current_point_index]

        distance_to_target = self.calculate_distance_to_target(target_x, target_y)
        angle_to_target = self.calculate_angle_to_target(target_x, target_y)

        

        

        target_x,target_y = self.path_points[self.current_point_index]

        if distance_to_target > 0.1:
            linear_speed =min(0.2 * distance_to_target,0.2)
            angular_speed= 1.0 * angle_to_target

            self.update_position(linear_speed, angular_speed)
        
        else:
            linear_speed = 0.0
            angular_speed = 0.0
            self.current_point_index += 1
            if self.current_point_index >=len(self.path_points):
                self.active = False
          


          

        
        
        #
        self.publish_velocity(linear_speed, angular_speed)
        
        # 
        self.update_position(linear_speed, angular_speed)
        
        # 
        self.publish_joint_state(linear_speed, angular_speed)
        
        #
        self.broadcast_transform()
    

    def calculate_distance_to_target(self, target_x, target_y):
        return math.sqrt((target_x - self.x) ** 2 + (target_y - self.y) ** 2)

    def calculate_angle_to_target(self, target_x, target_y):
        return math.atan2(target_y - self.y, target_x - self.x) - self.theta

    def publish_velocity(self, linear, angular):
        twist = Twist()
        twist.linear.x = linear
        twist.angular.z = angular
        self.velocity_publisher.publish(twist)

    def update_position(self, linear, angular):
        delta_time = 0.1  
          
        delta_x = linear * np.cos(self.theta) * delta_time  
        delta_y = linear * np.sin(self.theta) * delta_time  
        self.x +=delta_x
        self.y +=delta_y
        
        
        self.theta += angular * delta_time
        self.theta = self.normalize_angle(self.theta)
    
    def normalize_angle(self, angle):
        while angle > np.pi:

            angle -= 2.0 * np.pi
        while angle < -np.pi:
            angle += 2.0 * np.pi
        return angle

    
    def publish_joint_state(self, linear, angular):
        self.joint_state = JointState()
        self.joint_state.header.stamp = self.get_clock().now().to_msg()
        self.joint_state.header.frame_id = 'odom'
        self.joint_state.name = ['left_wheel_joint', 'right_wheel_joint']
        self.joint_state.position = [self.left_wheel_joint_rotation, self.right_wheel_joint_rotation]
        self.joint_state.velocity = [linear, angular]  # Simplified, typically you'd calculate the actual wheel velocities
        self.joint_state.effort = [0.0, 0.0]
        self.joint_state_publisher.publish(self.joint_state)


    def broadcast_transform(self):
        self.time_now = self.get_clock().now().to_msg()
        transform = TransformStamped()
        transform.header.stamp = self.time_now
        transform.header.frame_id = 'odom'
        transform.child_frame_id = 'base_link'
        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.translation.z = 0.0
        q = tf_trans.quaternion_from_euler(0, 0, self.theta)
        transform.transform.rotation = Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])
        self.odom_broadcaster.sendTransform(transform)

def main(args=None):
    rclpy.init(args=args)
    robot = RobotMotion()
    
    try:
        rclpy.spin(robot)
    except KeyboardInterrupt:
        robot.get_logger().info('Quitting the program...')
        robot.destroy_node()
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()


