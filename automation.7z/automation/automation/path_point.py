import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from sensor_msgs.msg import JointState
from visualization_msgs.msg import MarkerArray
from geometry_msgs.msg import PoseStamped, PointStamped,Quaternion
from visualization_msgs.msg import Marker
from std_msgs.msg import Header
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import tf_transformations as tf_trans
import numpy as np
class PathPointDemoNode(Node):
    def __init__(self):

        super().__init__('path_point')
        self.markerArray = MarkerArray()  # Target point marker array
        self.initial_pose_pub = self.create_publisher(PoseStamped, '/initialpose', 10)
        self.set_initial_pose()
        self.nav_action_client=ActionClient(self,NavigateToPose,'navigation_to_pose')
        self.count = 0
        self.index = 0
        self.try_again = 1

      
   
     
    

        # Create publishers and subscribers
        self.marker_pub = self.create_publisher(MarkerArray, '/path_point', 10)
        self.goal_pub = self.create_publisher(PoseStamped, '/move_base_simple/goal', 10)
        self.navGoal_sub = self.create_subscription(PoseStamped, '/goal_status', self.navGoal_callback, 10)
        self.click_sub = self.create_subscription(PointStamped, '/clicked_point', self.click_callback, 10)
        self.joint_state_publisher = self.create_publisher(JointState, 'joint_states', 10)
        self.odom_broadcaster = TransformBroadcaster(self)
    
    
        
    

    def click_callback(self,msg):
        self.get_logger().info(f'Add a new target point {self.count}:x: {msg.point.x}, y: {msg.point.y}, z:0, w:1')
        marker = Marker()
        marker.header.frame_id = 'odom'
        marker.type = Marker.ARROW
        marker.action = Marker.ADD
        marker.scale.x = 0.2
        marker.scale.y = 0.05
        marker.scale.z = 0.05
        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.pose.position.x = msg.point.x
        marker.pose.position.y = msg.point.y
        marker.pose.position.z = 0.0

        marker.id= 0
        self.markerArray.markers.append(marker)
        self.marker_pub.publish(self.markerArray)

        self.count += 1
        if self.count == 1:
            goal = PoseStamped()
            goal.header.frame_id = marker.header.frame_id
            goal.header.stamp = self.get_clock().now().to_msg()
            goal.pose.position.x = marker.pose.position.x
            goal.pose.position.y = marker.pose.position.y
            goal.pose.orientation.z = 0.0
            goal.pose.orientation.w = 1.0
            self.goal_pub.publish(goal)
    def set_initial_pose(self):
        initial_pose = PoseStamped()
        initial_pose.header.frame_id = 'odom'
        initial_pose.header.stamp = self.get_clock().now().to_msg()
        initial_pose.pose.position.x = 0.0  
        initial_pose.pose.position.y = 0.0
        initial_pose.pose.position.z = 0.0
        initial_pose.pose.orientation.x = 0.0
        initial_pose.pose.orientation.y = 0.0
        initial_pose.pose.orientation.z = 0.0
        initial_pose.pose.orientation.w = 1.0
        self.initial_pose_pub.publish(initial_pose)

    def broadcast_transform(self):
        self.time_now = self.get_clock().now().to_msg()
        transform = TransformStamped()
        transform.header.stamp = self.time_now
        transform.header.frame_id = 'odom'
        transform.child_frame_id = 'base_link'
        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.translation.z = 0.0
        q = tf_trans.quaternion_from_euler(0, 0, self.theta)
        transform.transform.rotation = Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])
        self.odom_broadcaster.sendTransform(transform)
   

    def publish_joint_state(self, linear, angular):
        joint_state = JointState()
        joint_state.header.stamp = self.get_clock().now().to_msg()
        joint_state.header.frame_id ='odom'
        joint_state.name = ['left_wheel_joint', 'right_wheel_joint']
        #joint_state.position = [self.left_wheel_rotation, self.right_wheel_rotation]
        joint_state.velocity = [linear, angular]  # Simplified, typically you'd calculate the actual wheel velocities
        joint_state.effort = [0.0, 0.0]
        self.joint_state_publisher.publish(joint_state)   
    

    def navGoal_callback(self,msg):
        
        
        if self.count > 0:
            status = msg.status_list[0]
            if status.status == 3:  # Successful arrival at the goal
                self.try_again = 1  # Allow retrying to reach unreached target points

                if self.index == self.count:
                    self.get_logger().info(f'Reach the target point {self.index - 1}:')
                    last_marker = self.markerArray.markers[self.index - 1]
                    self.get_logger().info(f'x: {last_marker.pose.position.x}, y: {last_marker.pose.position.y}, z: {last_marker.pose.position.z}, w: {last_marker.pose.orientation.w}')

                    if self.count > 1:
                        self.get_logger().info('Complete instructions!')
                        self.index = 0

                    pose = PoseStamped()
                    pose.header = Header()
                    pose.header.frame_id = 'odom'
                    pose.header.stamp = self.get_clock().now().to_msg()
                    last_marker = self.markerArray.markers[self.index]
                    pose.pose.position.x = last_marker.pose.position.x
                    pose.pose.position.y = last_marker.pose.position.y
                    pose.pose.orientation.z = last_marker.pose.orientation.z
                    pose.pose.orientation.w = last_marker.pose.orientation.w
                    self.goal_pub.publish(pose)
                    self.index += 1

                elif self.index < self.count:
                    self.get_logger().info(f'Reach the target point {self.index - 1}:')
                    last_marker = self.markerArray.markers[self.index - 1]
                    self.get_logger().info(f'x: {last_marker.pose.position.x}, y: {last_marker.pose.position.y}, z: {last_marker.pose.position.z}, w: {last_marker.pose.orientation.w}')

                    pose = PoseStamped()
                    pose.header = Header()
                    pose.header.frame_id = 'odom'
                    pose.header.stamp = self.get_clock().now().to_msg()
                    last_marker = self.markerArray.markers[self.index]
                    pose.pose.position.x = last_marker.pose.position.x
                    pose.pose.position.y = last_marker.pose.position.y
                    pose.pose.orientation.z = last_marker.pose.orientation.z
                    pose.pose.orientation.w = last_marker.pose.orientation.w
                    self.goal_pub.publish(pose)
                    self.index += 1

            elif status.status != 4:
                self.get_logger().warn(f'Can not reach the target point {self.index - 1}:')
                last_marker = self.markerArray.markers[self.index - 1]
                self.get_logger().warn(f'x: {last_marker.pose.position.x}, y: {last_marker.pose.position.y}, z: {last_marker.pose.position.z}, w: {last_marker.pose.orientation.w}')

                if self.try_again == 1:
                    self.get_logger().warn(f'Trying to reach the target point {self.index - 1} again!')
                    last_marker = self.markerArray.markers[self.index - 1]
                    pose = PoseStamped()
                    pose.header = Header()
                    pose.header.frame_id = 'odom'
                    pose.header.stamp = self.get_clock().now().to_msg()
                    pose.pose.position.x = last_marker.pose.position.x
                    pose.pose.position.y = last_marker.pose.position.y
                    pose.pose.orientation.z = last_marker.pose.orientation.z
                    pose.pose.orientation.w = last_marker.pose.orientation.w
                    self.goal_pub.publish(pose)
                    self.try_again = 0

                elif self.index < len(self.markerArray.markers):
                    self.get_logger().warn(f'Try reaching the target point {self.index - 1} failed! Trying to reach the next point:')
                    last_marker = self.markerArray.markers[self.index - 1]
                    pose = PoseStamped()
                    pose.header = Header()
                    pose.header.frame_id = 'odom'
                    pose.header.stamp = self.get_clock().now().to_msg()
                    pose.pose.position.x = last_marker.pose.position.x
                    pose.pose.position.y = last_marker.pose.position.y
                    pose.pose.orientation.z = last_marker.pose.orientation.z
                    pose.pose.orientation.w = last_marker.pose.orientation.w
                    self.goal_pub.publish(pose)
                    self.index += 1
                    self.try_again = 1
                    if self.index == self.count:
                        self.index = 0 
                        pose = PoseStamped()
                        pose.header.frame_id = 'odom'
                        pose.header.stamp = self.get_clock().now().to_msg()
                        pose.pose.position.x = self.markerArray.markers[self.index].pose.position.x
                        pose.pose.position.y = self.markerArray.markers[self.index].pose.position.y
                        pose.pose.orientation.z = self.markerArray.markers[self.index].pose.orientation.z
                        pose.pose.orientation.w = self.markerArray.markers[self.index].pose.orientation.w
                        self.goal_pub.publish(pose)
                        self.index += 1  

                        self.try_again = 1 
        
     


def main(args=None):
    rclpy.init(args=args)
    path_point = PathPointDemoNode()
    rclpy.spin(path_point)
    path_point.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

    

