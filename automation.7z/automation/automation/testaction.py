import rclpy
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose

def main():
    rclpy.init()
    node = rclpy.create_node("navigation_goal")

    client = ActionClient(node, NavigateToPose, "navigate_to_pose")
    node.get_logger().info("Waiting for the move_base action server")
    if not client.wait_for_server(timeout_sec=5.0):
        node.get_logger().info("Failed to connect to move_base server")
        return

    node.get_logger().info("Connected to move_base server")

    goal = NavigateToPose.Goal()
    goal.pose.header.frame_id = "odom"
    goal.pose.header.stamp = node.get_clock().now().to_msg()

    goal.pose.pose.position.x = 0.995
    goal.pose.pose.position.y = -2.99

    goal.pose.pose.orientation.x = 0.0
    goal.pose.pose.orientation.y = 0.0
    goal.pose.pose.orientation.z = 0.0
    goal.pose.pose.orientation.w = 1.0

    node.get_logger().info("Sending goal")
    future = client.send_goal_async(goal)
    rclpy.spin_until_future_complete(node, future)

    if future.result():
        if future.result().result.code == NavigateToPose.Result.SUCCESS:
            node.get_logger().info("Excellent! Your robot has reached the goal position.")
        else:
            node.get_logger().info("The robot failed to reach the goal position")
    else:
        node.get_logger().info("Failed to get a result")

    rclpy.shutdown()

if __name__ == "__main__":
    main()
