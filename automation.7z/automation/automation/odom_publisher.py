

import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import tf_transformations

class OdomPublisherNode(Node):
    def __init__(self):
        super().__init__('odom_publisher')
        self.broadcaster = TransformBroadcaster(self)
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.publish_odom_transform)

        # Initialize the pose
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        self.get_logger().info("OdomPublisher is running...")

    def publish_odom_transform(self):
        # Here you would integrate your velocity commands to update the pose
        # For now, we are assuming static pose for simplicity

        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = 'odom'
        t.child_frame_id = 'base_link'

        # Set the pose
        t.transform.translation.x = self.x
        t.transform.translation.y = self.y
        t.transform.translation.z = 0.0

        # Use tf_transformations to create a quaternion from yaw
        q = tf_transformations.quaternion_from_euler(0, 0, self.theta)
        
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]

        # Send the transformation
        self.broadcaster.sendTransform(t)

def main(args=None):
    rclpy.init(args=args)
    node = OdomPublisherNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
