
import launch_ros.actions
from launch import LaunchDescription

def generate_launch_description():
    return LaunchDescription([
        launch_ros.actions.Node(
            package='amcl',
            executable='amcl',
            name='amcl',
            output='screen',
            parameters=[
                {'odom_frame_id': 'odom'},
                {'odom_model_type': 'diff-corrected'},
                {'base_frame_id': 'base_link'},
                
                {'transform_tolerance': 0.2},
               
            ]
        ),
        launch_ros.actions.Node(
            package='move_base',
            executable='move_base',
            name='move_base',
            output='screen',
            remappings=[
                ('cmd_vel', 'cmd_vel'),
                ('odom', 'odom')
            ],
            parameters=[
                # Add any parameters for move_base as needed
            ],
        )
    ])
