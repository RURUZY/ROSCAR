import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Quaternion
from sensor_msgs.msg import Joy, JointState
from tf2_ros import TransformBroadcaster
import tf_transformations as tf_trans
from geometry_msgs.msg import TransformStamped
import numpy as np

class RobotClass(Node):
    
    def __init__(self):
        super().__init__('telema_node')
        self.velocity_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.joint_state_publisher = self.create_publisher(JointState, 'joint_states', 10)
        self.joystick_sub = self.create_subscription(Joy, 'joy', self.joystick_callback, 10)
        self.odom_broadcaster = TransformBroadcaster(self)
        
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.left_wheel_rotation = 0.0
        self.right_wheel_rotation = 0.0
        timer_period=0.1
        self.timer= self.create_timer(timer_period, self.broadcast_transform)
        self.get_logger().info("Telema is running...")

    def joystick_callback(self, msg):
        linear_speed = 0.06 * msg.axes[1]  #adjust the direction
        angular_speed = 0.1 * msg.axes[0]
        
        self.publish_velocity(linear_speed, angular_speed)
        self.update_position(linear_speed, angular_speed)
        self.publish_joint_state(linear_speed, angular_speed)
        self.broadcast_transform()

    def publish_velocity(self, linear, angular):
        twist = Twist()
        twist.linear.x = linear
        twist.angular.z = angular
        self.velocity_publisher.publish(twist)

    def update_position(self, linear, angular):
        delta_time = 0.1  
        self.x += linear * np.cos(self.theta) * delta_time
        self.y += linear * np.sin(self.theta) * delta_time
        self.theta += angular * delta_time
        
        # Simulate wheel rotations based on velocity and time
        wheel_radius = 0.1  #robot's wheel radius
        wheel_base = 0.1  #robot's wheel base width
        #self.left_wheel_rotation += (linear - angular * wheel_base / 2) * delta_time / wheel_radius
        #self.right_wheel_rotation += (linear + angular * wheel_base / 2) * delta_time / wheel_radius

    def publish_joint_state(self, linear, angular):
        joint_state = JointState()
        joint_state.header.stamp = self.get_clock().now().to_msg()
        joint_state.name = ['left_wheel_joint', 'right_wheel_joint']
        #joint_state.position = [self.left_wheel_rotation, self.right_wheel_rotation]
        joint_state.velocity = [linear, angular]  # Simplified, typically you'd calculate the actual wheel velocities
        joint_state.effort = [0.0, 0.0]
        self.joint_state_publisher.publish(joint_state)

    def broadcast_transform(self):
        self.time_now = self.get_clock().now().to_msg()
        transform = TransformStamped()
        transform.header.stamp = self.time_now
        transform.header.frame_id = 'odom'
        transform.child_frame_id = 'base_link'
        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.translation.z = 0.0
        q = tf_trans.quaternion_from_euler(0, 0, self.theta)
        transform.transform.rotation = Quaternion(x=q[0], y=q[1], z=q[2], w=q[3])
        self.odom_broadcaster.sendTransform(transform)

def main(args=None):
    rclpy.init(args=args)
    robot = RobotClass()
    
    try:
        rclpy.spin(robot)
    except KeyboardInterrupt:
        robot.get_logger().info('Quitting the program...')
        robot.destroy_node()
    finally:
        rclpy.shutdown()

if __name__ == '__main__':
    main()
